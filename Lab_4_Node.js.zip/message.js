
const msg1 = "Hello, this is my first Node.js program!";
const msg2 = "I am excited to learn more about Node.js!";
const msg3 = `${msg1 + msg2}`;

console.log(msg1);
console.log(msg2);
console.log(msg3);